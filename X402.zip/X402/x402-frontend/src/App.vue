<template>
  <div class="container">
    <h1>Conflux x402 支付网关 Demo</h1>
    <div class="card">
      <!-- 1. 基础操作区 -->
      <div class="operate">
        <button @click="generateOrderId">生成唯一订单ID</button>
        <p v-if="orderId">当前订单ID：{{ orderId }}</p>
        <button @click="requestContent" :disabled="!orderId">请求付费内容</button>
      </div>

      <!-- 2. 402支付提示区（未支付时显示） -->
      <div v-if="show402" class="alert-402">
        <h3>⚠️ HTTP 402 - Payment Required</h3>
        <p>需支付 {{ (payAmount / 1000000).toFixed(6) }} USDC 解锁内容</p>
        <p>合约地址：{{ payInfo.x402ContractAddress }}</p>
        <button @click="connectWallet" v-if="!walletAddress">连接MetaMask钱包</button>
        <p v-if="walletAddress">已连接：{{ shortenAddress(walletAddress) }}</p>
        <button @click="payOrder" v-if="walletAddress && orderId" class="pay-btn">
          一键支付（Conflux测试网）
        </button>
      </div>

      <!-- 3. 支付成功/内容展示区 -->
      <div v-if="showContent" class="content">
        <h3>✅ 支付成功！已解锁x402付费内容</h3>
        <p>{{ contentText }}</p>
      </div>

      <!-- 4. 状态提示区 -->
      <p class="status" v-if="statusText">{{ statusText }}</p>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { ethers } from 'ethers';
import axios from 'axios';

// 后端基础地址（对应后端端口3001，不要改）
const API_BASE = 'http://localhost:3001/api';
// 响应式数据
const orderId = ref('');
const show402 = ref(false);
const payInfo = ref({});
const payAmount = ref(1000); // USDC最小单位，和后端一致
const walletAddress = ref('');
const showContent = ref(false);
const contentText = ref('');
const statusText = ref('');

// 1. 生成唯一订单ID
const generateOrderId = () => {
  orderId.value = `api_${Date.now()}`;
  show402.value = false;
  showContent.value = false;
  statusText.value = '';
};

// 2. 请求付费内容（触发x402判断）
const requestContent = async () => {
  try {
    statusText.value = '正在请求内容...';
    const res = await axios.get(`${API_BASE}/access-content?orderId=${orderId.value}`);
    // 已支付：直接展示内容
    showContent.value = true;
    contentText.value = res.data.content;
    show402.value = false;
    statusText.value = '';
  } catch (err) {
    // 未支付：捕获402状态码，展示支付信息
    if (err.response && err.response.status === 402) {
      show402.value = true;
      payInfo.value = err.response.data.payInfo;
      payAmount.value = payInfo.value.amount;
      statusText.value = '';
    } else {
      statusText.value = `请求失败：${err.message}`;
    }
  }
};

// 3. 连接MetaMask钱包（自动切换Conflux eSpace测试网）
const connectWallet = async () => {
  if (!window.ethereum) {
    statusText.value = '请安装MetaMask钱包！';
    return;
  }

  try {
    // 请求钱包授权
    const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
    walletAddress.value = accounts[0];
    // 切换到Conflux eSpace测试网（链ID：71，16进制0x47）
    await window.ethereum.request({
      method: 'wallet_switchEthereumChain',
      params: [{ chainId: '0x47' }]
    });
    statusText.value = '钱包连接成功，已切换到Conflux测试网';
  } catch (err) {
    statusText.value = `钱包连接失败：${err.message}`;
  }
};

// 4. 一键支付（调用合约支付USDC，核心支付逻辑）
const payOrder = async () => {
  if (!window.ethereum || !walletAddress.value) return;
  try {
    statusText.value = '正在准备支付...请在钱包确认';
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    // USDC合约ABI（仅授权函数）
    const usdcAbi = ["function approve(address spender, uint256 amount) external returns (bool)"];
    const usdcContract = new ethers.Contract(payInfo.value.usdcAddress, usdcAbi, signer);
    const x402Contract = new ethers.Contract(
      payInfo.value.x402ContractAddress,
      ["function payOrder(string calldata orderId, uint256 amount) external"],
      signer
    );

    // 步骤1：授权x402合约花费USDC（必须！否则支付失败）
    await usdcContract.approve(payInfo.value.x402ContractAddress, payAmount.value);
    // 步骤2：调用x402合约完成支付
    const tx = await x402Contract.payOrder(orderId.value, payAmount.value);
    statusText.value = '支付交易已发送，等待链上确认...';
    // 等待交易上链
    await tx.wait();
    statusText.value = '支付成功！正在解锁内容...';
    // 自动请求内容
    setTimeout(() => {
      requestContent();
    }, 2000);
  } catch (err) {
    statusText.value = `支付失败：${err.message}`;
  }
};

// 辅助函数：缩短钱包地址显示
const shortenAddress = (addr) => {
  return addr ? `${addr.slice(0, 6)}...${addr.slice(-4)}` : '';
};
</script>

<style scoped>
.container {
  max-width: 800px;
  margin: 50px auto;
  text-align: center;
  font-family: Arial, sans-serif;
}
.card {
  border: 1px solid #e0e0e0;
  border-radius: 10px;
  padding: 30px;
  margin-top: 20px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}
button {
  padding: 10px 20px;
  margin: 5px;
  border: none;
  border-radius: 5px;
  background: #2c3e50;
  color: white;
  cursor: pointer;
  font-size: 14px;
}
button:disabled {
  background: #bdc3c7;
  cursor: not-allowed;
}
.pay-btn {
  background: #e74c3c;
  font-weight: bold;
}
.alert-402 {
  margin: 20px 0;
  padding: 20px;
  border: 1px solid #f39c12;
  border-radius: 5px;
  background: #fff3cd;
}
.content {
  margin: 20px 0;
  padding: 20px;
  border: 1px solid #27ae60;
  border-radius: 5px;
  background: #d4edda;
}
.status {
  margin-top: 20px;
  color: #e74c3c;
  font-weight: bold;
}
.operate {
  margin-bottom: 20px;
}
</style>