const express = require('express');
const ethers = require('ethers');
const dotenv = require('dotenv');
const cors = require('cors');
dotenv.config();

const app = express();
app.use(cors()); // 解决前端跨域问题
app.use(express.json());
const PORT = 3001; // 后端端口，后续前端要对应

// 1. 初始化Conflux连接和合约实例
const provider = new ethers.providers.JsonRpcProvider(process.env.CONFLUX_RPC_URL);
// 合约ABI（仅包含需要调用的函数，极简版，不用全量ABI）
const contractAbi = [
    "function payOrder(string calldata orderId, uint256 amount) external",
    "function checkOrderStatus(string calldata orderId) external view returns (bool)"
];
const x402Contract = new ethers.Contract(
    process.env.X402_CONTRACT_ADDRESS,
    contractAbi,
    provider
);

// 2. 接口1：获取付费信息（供前端展示：金额、合约地址等）
app.get('/api/pay-info', (req, res) => {
    const orderId = req.query.orderId || `api_${Date.now()}`; // 自动生成唯一订单ID
    res.json({
        orderId,
        amount: process.env.PAYMENT_AMOUNT, // 支付金额（USDC最小单位）
        usdcAddress: process.env.USDC_ADDRESS,
        x402ContractAddress: process.env.X402_CONTRACT_ADDRESS,
        desc: "需支付0.001 USDC解锁API内容（Conflux eSpace测试网）"
    });
});

// 3. 接口2：核心x402 API（访问内容入口，未支付返回402）
app.get('/api/access-content', async (req, res) => {
    const { orderId } = req.query;
    if (!orderId) {
        return res.status(400).json({ msg: "缺少orderId参数" });
    }

    try {
        // 查询订单支付状态
        const isPaid = await x402Contract.checkOrderStatus(orderId);
        if (isPaid) {
            // 已支付：返回解锁的内容（小白可自定义，如AI问答、数据等）
            return res.json({
                code: 200,
                msg: "支付成功，已解锁内容",
                content: "【x402付费内容】这是你支付0.001 USDC后解锁的AI分析数据：某基金近30天收益率5.2%，风险等级中，适合稳健型投资者。——由Conflux x402支付网关提供"
            });
        } else {
            // 未支付：返回HTTP 402状态码 + 付费信息（x402核心）
            return res.status(402).json({
                msg: "Payment Required - 需支付解锁内容",
                payInfo: {
                    orderId,
                    amount: process.env.PAYMENT_AMOUNT,
                    x402ContractAddress: process.env.X402_CONTRACT_ADDRESS,
                    usdcAddress: process.env.USDC_ADDRESS
                }
            });
        }
    } catch (err) {
        res.status(500).json({ msg: "服务器错误", error: err.message });
    }
});

// 4. 接口3：查询支付状态（供前端支付后轮询）
app.get('/api/pay-status', async (req, res) => {
    const { orderId } = req.query;
    if (!orderId) {
        return res.status(400).json({ msg: "缺少orderId参数" });
    }

    try {
        const isPaid = await x402Contract.checkOrderStatus(orderId);
        res.json({ orderId, isPaid });
    } catch (err) {
        res.status(500).json({ msg: "查询失败", error: err.message });
    }
});

// 启动后端服务
app.listen(PORT, () => {
    console.log(`x402后端服务运行中：http://localhost:${PORT}`);
    console.log(`合约地址：${process.env.X402_CONTRACT_ADDRESS}`);
});